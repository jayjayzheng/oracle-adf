package com.redsamurai.view.beans;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.controller.ControllerContext;
import oracle.adf.controller.TaskFlowId;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.jbo.ApplicationModule;


public class DynamicRegionsBean {
    private String taskFlowId = "/WEB-INF/locations-flow.xml#locations-flow";
    private RichPopup _popup;

    public TaskFlowId getDynamicTaskFlowId() {
        return TaskFlowId.parse(taskFlowId);
    }

    public String departmentsflow() {
        if (this.pendingChangesExist()) {
            RichPopup.PopupHints hints = new RichPopup.PopupHints();
            _popup.show(hints);
            AdfFacesContext fctx = AdfFacesContext.getCurrentInstance();
            fctx.getPageFlowScope().put("taskFlowId", "/WEB-INF/departments-flow.xml#departments-flow");
        } else {
          taskFlowId = "/WEB-INF/departments-flow.xml#departments-flow";
        }
        return null;
    }

    public String locationsflow() {
          if (this.pendingChangesExist()) {
              RichPopup.PopupHints hints = new RichPopup.PopupHints();
              _popup.show(hints);
              AdfFacesContext fctx = AdfFacesContext.getCurrentInstance();
              fctx.getPageFlowScope().put("taskFlowId", "/WEB-INF/locations-flow.xml#locations-flow");
          } else {
            taskFlowId = "/WEB-INF/locations-flow.xml#locations-flow";
          }
          return null;
    }

    public String jobsflow() {
        if (this.pendingChangesExist()) {
            RichPopup.PopupHints hints = new RichPopup.PopupHints();
            _popup.show(hints);
            AdfFacesContext fctx = AdfFacesContext.getCurrentInstance();
            fctx.getPageFlowScope().put("taskFlowId", "/WEB-INF/jobs-flow.xml#jobs-flow");
        } else {
          taskFlowId = "/WEB-INF/jobs-flow.xml#jobs-flow";
        }
        return null;
    }

    public String employeesflow() {
        if (this.pendingChangesExist()) {
            RichPopup.PopupHints hints = new RichPopup.PopupHints();
            _popup.show(hints);
            AdfFacesContext fctx = AdfFacesContext.getCurrentInstance();
            fctx.getPageFlowScope().put("taskFlowId", "/WEB-INF/employees-flow.xml#employees-flow");
        } else {
          taskFlowId = "/WEB-INF/employees-flow.xml#employees-flow";
        }
        return null;
    }
    
    private boolean pendingChangesExist() {
        /** How to get the controller context
         *  The ControlleContext class provides per-request information about the controller state for
         *  a web application.
         */
        ControllerContext cctx = ControllerContext.getInstance();
        return cctx.getCurrentViewPort().getTaskFlowContext().isDataDirty();
    }
    
    private ApplicationModule getApplicationModule(String dataProvider) {
        FacesContext fc = FacesContext.getCurrentInstance();
        Application app = fc.getApplication();
        ExpressionFactory elFactory = app.getExpressionFactory();
        ELContext elContext = fc.getELContext();
        ValueExpression valueExp = elFactory.createValueExpression(elContext, dataProvider, Object.class);
            
        return (ApplicationModule)valueExp.getValue(elContext);
    }

    public void set_popup(RichPopup _popup) {
        this._popup = _popup;
    }

    public RichPopup get_popup() {
        return _popup;
    }

    public void continueAction(ActionEvent actionEvent) {
        AdfFacesContext fctx = AdfFacesContext.getCurrentInstance();
        
        if(this.taskFlowId.equals("/WEB-INF/departments-flow.xml#departments-flow")) {
            this.getApplicationModule("#{data.DepartmentsModuleDataControl.dataProvider}").getTransaction().rollback();
        }
        
        if(this.taskFlowId.equals("/WEB-INF/employees-flow.xml#employees-flow")) {
            this.getApplicationModule("#{data.EmployeesModuleDataControl.dataProvider}").getTransaction().rollback();
        }
        
        if(this.taskFlowId.equals("/WEB-INF/jobs-flow.xml#jobs-flow")) {
            this.getApplicationModule("#{data.JobsModuleDataControl.dataProvider}").getTransaction().rollback();
        }
        
        if(this.taskFlowId.equals("/WEB-INF/locations-flow.xml#locations-flow")) {
            this.getApplicationModule("#{data.LocationsModuleDataControl.dataProvider}").getTransaction().rollback();
        }
        taskFlowId = (String)fctx.getPageFlowScope().get("taskFlowId");
    }
}
