package portal.beans.navigation;

import java.util.Hashtable;

import oracle.adf.rc.catalog.CatalogElement;
import oracle.adf.rc.catalog.ElementParameters;
import oracle.adf.rc.spi.plugin.catalog.CatalogDefinitionFilter;

public class NavigationFilter implements CatalogDefinitionFilter {

    public boolean includeInCatalog(CatalogElement catalogElement, Hashtable hashtable) {
        
        if (catalogElement.getId()!= null && !catalogElement.getId().equalsIgnoreCase("pages")) {
            ElementParameters params = catalogElement.getLocalParameters();    
            if (params != null) {
                String param = params.get("showFlag").getValue();
                if (param != null && param.trim().equalsIgnoreCase("Y")) {
                    return true;    
                } else {
                    return false;    
                }
            }
            
        }
        return true;
    }
}
