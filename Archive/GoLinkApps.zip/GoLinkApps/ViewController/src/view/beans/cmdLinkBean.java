package view.beans;

import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.data.RichTable;


public class cmdLinkBean {

    public cmdLinkBean() {
    }

    public void onClick(ActionEvent actionEvent) {
        RichTable table = (RichTable)actionEvent.getComponent().getParent().getParent();
        System.out.println("the selected data is: " + table.getSelectedRowData().toString());
    }
}
