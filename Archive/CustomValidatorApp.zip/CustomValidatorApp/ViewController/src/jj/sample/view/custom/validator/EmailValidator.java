package jj.sample.view.custom.validator;

import java.io.Serializable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class EmailValidator implements Serializable, Validator {
  public EmailValidator() {
    super();
  }

  public void validate(FacesContext facesContext, UIComponent uIComponent,
                       Object object) {
    String value = (String)object;
    if ((value == null) || value.length() == 0) {
      return;  
    }
    
    String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
    CharSequence inputStr = value;
    Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
    Matcher matcher = pattern.matcher(inputStr);
    if (!matcher.matches()) {
      throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                                    "The Email is not valid.",
                                                    null));
    }
  }
}
