package jj.sample.view.custom.validator;

import java.io.Serializable;

import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import oracle.adf.view.rich.component.rich.input.RichInputDate;

public class DateMustComeAfterValidator implements Serializable, Validator {
  public DateMustComeAfterValidator() {
    super();
  }

  public void validate(FacesContext facesContext, UIComponent uIComponent,
                       Object object) throws ValidatorException {
    //get component id by get("AttributeName");
    String startDateComponentId = (String)uIComponent.getAttributes().get("startDateComponentId");
    RichInputDate startDateComponent = (RichInputDate)uIComponent.findComponent(startDateComponentId);
    Date startDate = (Date)startDateComponent.getValue();
    Date endDate = (Date)object;
    //get labels from the two inputDate component.
    String startDateLabel = startDateComponent.getLabel();
    String endDateLabel = ((RichInputDate)uIComponent).getLabel();
    //throw error if valiation fails
    if ((startDate == null) || (endDate == null) || (endDate.compareTo(startDate) < 0)) {
      throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_ERROR,
              "The " + endDateLabel + " should be greater than " + startDateLabel +".",
                                                    null));  
    }
  }
}
