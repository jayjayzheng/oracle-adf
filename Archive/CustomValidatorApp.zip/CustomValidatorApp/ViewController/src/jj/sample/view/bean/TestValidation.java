package jj.sample.view.bean;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.input.RichInputDate;
import oracle.adf.view.rich.component.rich.input.RichInputText;

public class TestValidation {
  private RichInputText email;
  private RichInputDate startDate;
  private RichInputDate endDate;

  public TestValidation() {
  }

  public void testValiations(ActionEvent actionEvent) {
    // Add event code here...
    FacesContext fctx = FacesContext.getCurrentInstance();
    if ((getEmail().getValue() == null) && 
        (getStartDate().getValue() == null) && 
        (getEndDate().getValue() == null)) {
        fctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
                                               "No Values entered!",
                                               null));
    } else if ((getStartDate().getValue()!=null)&&(getEndDate().getValue()==null)) {
      fctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                             "Please enter a value in the End Date",
                                             null));
    } else {
        fctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                                               "Validations test passed!",
                                               null));
      }
  }

  public void setEmail(RichInputText email) {
    this.email = email;
  }

  public RichInputText getEmail() {
    return email;
  }

  public void setStartDate(RichInputDate startDate) {
    this.startDate = startDate;
  }

  public RichInputDate getStartDate() {
    return startDate;
  }

  public void setEndDate(RichInputDate endDate) {
    this.endDate = endDate;
  }

  public RichInputDate getEndDate() {
    return endDate;
  }
}
